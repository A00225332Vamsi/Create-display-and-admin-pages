﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductManage.Models
{
    public class Shippers
    {
        [Key]
        public int shipperlD { get; set; }
        [Required(ErrorMessage = "Please enter Company Name")]
        [Display(Name = "Company Name")]
        [StringLength(150)]
        public string companyName { get; set; }

        [Required(ErrorMessage = "Please enter Phone")]
        [Display(Name = "Phone")]
        [StringLength(150)]
        public string phone { get; set; }
    }
}

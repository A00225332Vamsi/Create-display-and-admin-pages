﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductManage.Models.ViewModels
{
    public class ProductViewModel
    {
      
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Please enter Product Name")]
        [Display(Name = "Product Name")]
        [StringLength(150)]
        public string ProductName { get; set; }
        public int CategorylD { get; set; }
        public int SupplierlD { get; set; }
        public string QuantityPerLabel { get; set; }
        public float UnitPrice { get; set; }
        public int UnitslnStock { get; set; }
        public int UnitsOnOrder { get; set; }
        public int ReorderLevel { get; set; }
        public bool Discontinued { get; set; }
        public Categories Category { get; set; }
        public Suppliers Supplier { get; set; }
        [Required(ErrorMessage = "Please choose image")]
        [Display(Name = "image")]
        public IFormFile Image { get; set; }
    }
}

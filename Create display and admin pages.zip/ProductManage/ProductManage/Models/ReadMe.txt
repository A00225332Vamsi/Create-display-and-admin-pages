﻿



add-migration MigrationName
update-database
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductManage.Models
{
    public class Categories
    {
        //public Categories()
        //{
        //    this.Products = new HashSet<Products>();
        //}
        [Key]
        public int CategorylD { get; set; }
        [Required(ErrorMessage = "Please enter Category Name")]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }
        public string Description { get; set; }
        //public string Picture { get; set; }
        //public virtual ICollection<Products> Products { get; set; }
    }
}
